"""Read-only MySQL access for deal activity data."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any, Protocol

import pymysql
from pymysql.cursors import DictCursor

from .ad_models import AD_ANALYSIS_FIELDS, AdAnalysisInput, AdToolName
from .config import DatabaseSettings
from .models import (
    DEAL_DETAIL_FIELDS,
    PARENT_ASIN_PERFORMANCE_FIELDS,
    SEARCH_DEAL_FIELDS,
    GetDealItemsInput,
    JsonRecord,
    ParentAsinPerformanceInput,
    SearchDealsInput,
)


@dataclass(frozen=True, slots=True)
class SearchResult:
    items: list[JsonRecord]
    total: int


@dataclass(frozen=True, slots=True)
class DealItemsResult:
    items: list[JsonRecord]
    total: int


@dataclass(frozen=True, slots=True)
class ParentAsinPerformanceResult:
    items: list[JsonRecord]
    total: int


@dataclass(frozen=True, slots=True)
class AdAnalysisResult:
    items: list[JsonRecord]
    total: int


@dataclass(frozen=True, slots=True)
class AdAnalysisSpec:
    view: str
    date_field: str
    optional_filters: tuple[str, ...]
    order_by: tuple[str, ...]


AD_ANALYSIS_SPECS: dict[str, AdAnalysisSpec] = {
    "get_ad_portfolios": AdAnalysisSpec(
        view="v_e_ads_portfolios_analysis",
        date_field="report_date",
        optional_filters=("portfolio_id",),
        order_by=("report_date", "market_id", "portfolio_id"),
    ),
    "get_ad_campaigns": AdAnalysisSpec(
        view="v_e_ads_merge_campaigns_analysis",
        date_field="report_date",
        optional_filters=("campaign_id",),
        order_by=("report_date", "market_id", "campaign_id"),
    ),
    "get_ad_placements": AdAnalysisSpec(
        view="v_e_ads_merge_placement_analysis",
        date_field="report_date",
        optional_filters=("campaign_id", "placement_merge"),
        order_by=("report_date", "market_id", "campaign_id", "placement_merge"),
    ),
    "get_ad_products": AdAnalysisSpec(
        view="v_e_ads_merge_product_analysis",
        date_field="report_date",
        optional_filters=("msku", "market_id"),
        order_by=("report_date", "market_id", "msku", "asin"),
    ),
    "get_ad_targetings": AdAnalysisSpec(
        view="v_e_ads_merge_targeting_analysis",
        date_field="report_date",
        optional_filters=("market_id", "target_id"),
        order_by=("report_date", "market_id", "campaign_id", "group_id", "target_id"),
    ),
    "get_ad_negative_targetings": AdAnalysisSpec(
        view="v_e_ads_merge_negative_targeting_analysis",
        date_field="create_time",
        optional_filters=("market_id",),
        order_by=("create_time", "market_id", "campaign_id", "group_id", "expression_name"),
    ),
    "get_ad_search_terms": AdAnalysisSpec(
        view="v_e_ads_merge_searchterm_analysis",
        date_field="report_date",
        optional_filters=("market_id", "query"),
        order_by=("report_date", "market_id", "campaign_id", "group_id", "query"),
    ),
}


class DealRepository(Protocol):
    async def search(self, filters: SearchDealsInput) -> SearchResult:
        """Return one page and the total count for validated filters."""

    async def get_items(self, filters: GetDealItemsInput) -> DealItemsResult:
        """Return products in one deal and their total count."""

    async def get_parent_asin_performance(
        self,
        filters: ParentAsinPerformanceInput,
    ) -> ParentAsinPerformanceResult:
        """Return one page of daily performance and its total count."""

    async def get_ad_analysis(
        self,
        tool_name: AdToolName,
        filters: AdAnalysisInput,
    ) -> AdAnalysisResult:
        """Return one page from an allowlisted advertising analysis view."""


def _effective_dates(
    filters: SearchDealsInput | GetDealItemsInput,
    today: date | None = None,
) -> tuple[date, date]:
    current_date = today or date.today()
    end_date = filters.end_date or current_date
    return filters.start_date or end_date - timedelta(days=89), end_date


def _month_first(value: date, offset: int) -> date:
    month_index = value.year * 12 + value.month - 1 + offset
    year, zero_based_month = divmod(month_index, 12)
    return date(year, zero_based_month + 1, 1)


def _effective_deal_item_dates(
    filters: GetDealItemsInput,
    today: date | None = None,
) -> tuple[date, date]:
    current_date = today or date.today()
    if filters.start_date is None and filters.end_date is None:
        return _month_first(current_date, -1), _month_first(current_date, 2) - timedelta(days=1)
    return _effective_dates(filters, current_date)


def _selected_fields(requested: list[str] | None, default: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(requested) if requested else default


def build_search_queries(
    filters: SearchDealsInput,
    today: date | None = None,
) -> tuple[str, str, tuple[Any, ...], tuple[Any, ...]]:
    """Build parameterized deal-search statements from allowlisted fields."""
    start_date, end_date = _effective_dates(filters, today)
    where = ["i.market_id = %s"]
    values: list[Any] = [filters.market_id]
    if filters.deal_id:
        where.append("i.deal_id = %s")
        values.append(filters.deal_id)
    where.extend([
        "i.start_date >= %s",
        "i.start_date < DATE_ADD(%s, INTERVAL 1 DAY)",
    ])
    values.extend([start_date, end_date])
    if filters.status:
        where.append("i.status = %s")
        values.append(filters.status)
    if filters.deal_type:
        where.append("i.deal_type = %s")
        values.append(filters.deal_type)

    fields = _selected_fields(filters.returnFields, SEARCH_DEAL_FIELDS)
    select_expressions = []
    for field in fields:
        if field == "product_count":
            select_expressions.append(
                "(SELECT COUNT(DISTINCT detail.asin) "
                "FROM v_e_ads_deal_detail AS detail "
                "WHERE detail.deal_id = i.deal_id AND detail.market_id = i.market_id) "
                "AS product_count"
            )
        else:
            select_expressions.append(f"i.{field}")

    from_and_filters = (
        "FROM v_e_ads_deal_info AS i "
        f"WHERE {' AND '.join(where)}"
    )
    count_query = f"SELECT COUNT(*) AS total {from_and_filters}"
    offset = (filters.page - 1) * filters.page_size
    page_query = (
        f"SELECT {', '.join(select_expressions)} {from_and_filters} "
        "ORDER BY i.start_date DESC, i.deal_id ASC "
        "LIMIT %s OFFSET %s"
    )
    return page_query, count_query, tuple(values + [filters.page_size, offset]), tuple(values)


def build_deal_item_queries(
    filters: GetDealItemsInput,
    today: date | None = None,
) -> tuple[str, str, tuple[Any, ...], tuple[Any, ...]]:
    """Build parameterized deal-item statements from allowlisted fields."""
    start_date, end_date = _effective_deal_item_dates(filters, today)
    where: list[str] = []
    values: list[Any] = []
    if filters.market_id is not None:
        where.append("d.market_id = %s")
        values.append(filters.market_id)
    where.append("d.deal_id = %s")
    values.append(filters.deal_id)
    if filters.msku:
        where.append("d.msku = %s")
        values.append(filters.msku)
    where.extend([
        "d.start_date >= %s",
        "d.start_date < DATE_ADD(%s, INTERVAL 1 DAY)",
    ])
    values.extend([start_date, end_date])
    if filters.variation_asin:
        where.append("d.variation_asin = %s")
        values.append(filters.variation_asin)

    fields = _selected_fields(filters.returnFields, DEAL_DETAIL_FIELDS)
    from_and_filters = (
        "FROM v_e_ads_deal_detail AS d "
        f"WHERE {' AND '.join(where)}"
    )
    count_query = f"SELECT COUNT(*) AS total {from_and_filters}"
    offset = (filters.page - 1) * filters.page_size
    page_query = (
        f"SELECT {', '.join(f'd.{field}' for field in fields)} "
        f"{from_and_filters} "
        "ORDER BY d.asin ASC, d.sku ASC, d.msku ASC, d.spu ASC, d.id ASC "
        "LIMIT %s OFFSET %s"
    )
    return page_query, count_query, tuple(values + [filters.page_size, offset]), tuple(values)


def build_parent_asin_performance_queries(
    filters: ParentAsinPerformanceInput,
) -> tuple[str, str, tuple[Any, ...], tuple[Any, ...]]:
    """Build parameterized performance statements from allowlisted fields."""
    where = [
        "p.statistics_date >= %s",
        "p.statistics_date < DATE_ADD(%s, INTERVAL 1 DAY)",
    ]
    values: list[Any] = [
        filters.start_date,
        filters.end_date,
    ]
    if filters.variation_asin:
        where.append("p.variation_asin = %s")
        values.append(filters.variation_asin)
    if filters.brand:
        where.append("p.brand = %s")
        values.append(filters.brand)
    if filters.category_zh:
        where.append("p.category_zh = %s")
        values.append(filters.category_zh)
    if filters.country_code:
        where.append("p.country_code = %s")
        values.append(filters.country_code)
    if filters.country_name:
        where.append("p.country_name = %s")
        values.append(filters.country_name)

    fields = _selected_fields(filters.returnFields, PARENT_ASIN_PERFORMANCE_FIELDS)
    from_and_filters = (
        "FROM v_e_ads_sales_operations_variation_asin AS p "
        f"WHERE {' AND '.join(where)}"
    )
    count_query = f"SELECT COUNT(*) AS total {from_and_filters}"
    offset = (filters.page - 1) * filters.page_size
    page_query = (
        f"SELECT COUNT(*) OVER() AS _total, {', '.join(f'p.{field}' for field in fields)} "
        f"{from_and_filters} "
        "ORDER BY p.statistics_date DESC, p.country_code ASC, p.country_name ASC "
        "LIMIT %s OFFSET %s"
    )
    return page_query, count_query, tuple(values + [filters.page_size, offset]), tuple(values)


def build_ad_analysis_queries(
    tool_name: AdToolName,
    filters: AdAnalysisInput,
) -> tuple[str, str, tuple[Any, ...], tuple[Any, ...]]:
    """Build one parameterized advertising-analysis query from an immutable spec."""
    spec = AD_ANALYSIS_SPECS[tool_name]
    where = [
        "a.variation_asin = %s",
        f"a.{spec.date_field} >= %s",
        f"a.{spec.date_field} < DATE_ADD(%s, INTERVAL 1 DAY)",
    ]
    values: list[Any] = [filters.variation_asin, filters.start_date, filters.end_date]
    for field in spec.optional_filters:
        value = getattr(filters, field)
        if value is not None:
            where.append(f"a.{field} = %s")
            values.append(value)

    fields = _selected_fields(filters.returnFields, AD_ANALYSIS_FIELDS[tool_name])
    from_and_filters = f"FROM {spec.view} AS a WHERE {' AND '.join(where)}"
    count_query = f"SELECT COUNT(*) AS total {from_and_filters}"
    order_by = ", ".join(
        f"a.{field} DESC" if index == 0 else f"a.{field} ASC"
        for index, field in enumerate(spec.order_by)
    )
    offset = (filters.page - 1) * filters.page_size
    page_query = (
        f"SELECT COUNT(*) OVER() AS _total, {', '.join(f'a.{field}' for field in fields)} "
        f"{from_and_filters} ORDER BY {order_by} LIMIT %s OFFSET %s"
    )
    return page_query, count_query, tuple(values + [filters.page_size, offset]), tuple(values)


def _serialize_value(value: Any) -> str | int | float | bool | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, datetime):
        return value.isoformat(sep=" ", timespec="seconds")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def _project_row(row: dict[str, Any], fields: tuple[str, ...]) -> JsonRecord:
    return {field: _serialize_value(row.get(field)) for field in fields}


class MySqlDealRepository:
    """PyMySQL repository that executes only predefined SELECT statements."""

    def __init__(self, settings: DatabaseSettings) -> None:
        self._settings = settings

    async def search(self, filters: SearchDealsInput) -> SearchResult:
        return await asyncio.to_thread(self._search_sync, filters)

    async def get_items(self, filters: GetDealItemsInput) -> DealItemsResult:
        return await asyncio.to_thread(self._get_items_sync, filters)

    async def get_parent_asin_performance(
        self,
        filters: ParentAsinPerformanceInput,
    ) -> ParentAsinPerformanceResult:
        return await asyncio.to_thread(self._get_parent_asin_performance_sync, filters)

    async def get_ad_analysis(
        self,
        tool_name: AdToolName,
        filters: AdAnalysisInput,
    ) -> AdAnalysisResult:
        return await asyncio.to_thread(self._get_ad_analysis_sync, tool_name, filters)

    def _connect(self) -> pymysql.Connection:
        return pymysql.connect(
            host=self._settings.host,
            port=self._settings.port,
            user=self._settings.user,
            password=self._settings.password,
            database=self._settings.database,
            charset="utf8mb4",
            cursorclass=DictCursor,
            autocommit=True,
            connect_timeout=self._settings.connect_timeout_seconds,
            read_timeout=self._settings.read_timeout_seconds,
            write_timeout=self._settings.read_timeout_seconds,
        )

    def _search_sync(self, filters: SearchDealsInput) -> SearchResult:
        page_sql, count_sql, page_values, count_values = build_search_queries(filters)
        connection = self._connect()
        try:
            with connection.cursor() as cursor:
                cursor.execute(count_sql, count_values)
                count_row = cursor.fetchone() or {"total": 0}
                cursor.execute(page_sql, page_values)
                rows = cursor.fetchall()
        finally:
            connection.close()

        fields = _selected_fields(filters.returnFields, SEARCH_DEAL_FIELDS)
        return SearchResult(
            items=[_project_row(row, fields) for row in rows],
            total=int(count_row["total"]),
        )

    def _get_items_sync(self, filters: GetDealItemsInput) -> DealItemsResult:
        page_sql, count_sql, page_values, count_values = build_deal_item_queries(filters)
        connection = self._connect()
        try:
            with connection.cursor() as cursor:
                cursor.execute(count_sql, count_values)
                count_row = cursor.fetchone() or {"total": 0}
                cursor.execute(page_sql, page_values)
                rows = cursor.fetchall()
        finally:
            connection.close()

        fields = _selected_fields(filters.returnFields, DEAL_DETAIL_FIELDS)
        return DealItemsResult(
            items=[_project_row(row, fields) for row in rows],
            total=int(count_row["total"]),
        )

    def _get_parent_asin_performance_sync(
        self,
        filters: ParentAsinPerformanceInput,
    ) -> ParentAsinPerformanceResult:
        page_sql, count_sql, page_values, count_values = (
            build_parent_asin_performance_queries(filters)
        )
        connection = self._connect()
        try:
            with connection.cursor() as cursor:
                cursor.execute(page_sql, page_values)
                rows = cursor.fetchall()
                if rows:
                    total = int(rows[0]["_total"])
                else:
                    cursor.execute(count_sql, count_values)
                    count_row = cursor.fetchone() or {"total": 0}
                    total = int(count_row["total"])
        finally:
            connection.close()

        fields = _selected_fields(filters.returnFields, PARENT_ASIN_PERFORMANCE_FIELDS)
        return ParentAsinPerformanceResult(
            items=[_project_row(row, fields) for row in rows],
            total=total,
        )

    def _get_ad_analysis_sync(
        self,
        tool_name: AdToolName,
        filters: AdAnalysisInput,
    ) -> AdAnalysisResult:
        page_sql, count_sql, page_values, count_values = build_ad_analysis_queries(
            tool_name, filters,
        )
        connection = self._connect()
        try:
            with connection.cursor() as cursor:
                cursor.execute(page_sql, page_values)
                rows = cursor.fetchall()
                if rows:
                    total = int(rows[0]["_total"])
                else:
                    cursor.execute(count_sql, count_values)
                    count_row = cursor.fetchone() or {"total": 0}
                    total = int(count_row["total"])
        finally:
            connection.close()

        fields = _selected_fields(filters.returnFields, AD_ANALYSIS_FIELDS[tool_name])
        return AdAnalysisResult(
            items=[_project_row(row, fields) for row in rows],
            total=total,
        )
