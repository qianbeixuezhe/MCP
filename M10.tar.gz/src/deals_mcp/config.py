"""Configuration loading and validation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import tomllib
from typing import Any


class ConfigurationError(ValueError):
    """Raised when the server configuration is missing or invalid."""


@dataclass(frozen=True, slots=True)
class ServerSettings:
    host: str
    port: int
    mcp_path: str
    bearer_token: str
    allowed_hosts: tuple[str, ...]
    allowed_origins: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DatabaseSettings:
    host: str
    port: int
    user: str
    password: str
    database: str
    connect_timeout_seconds: int
    read_timeout_seconds: int


@dataclass(frozen=True, slots=True)
class AppConfig:
    server: ServerSettings
    database: DatabaseSettings


def _section(data: dict[str, Any], name: str) -> dict[str, Any]:
    value = data.get(name)
    if not isinstance(value, dict):
        raise ConfigurationError(f"配置缺少 [{name}] 段。")
    return value


def _required_string(section: dict[str, Any], key: str, section_name: str) -> str:
    value = section.get(key)
    if not isinstance(value, str):
        raise ConfigurationError(f"配置项 {section_name}.{key} 必须是字符串。")
    return value


def load_config(path: str | Path) -> AppConfig:
    """Load application settings from a TOML file."""
    config_path = Path(path).expanduser().resolve()
    try:
        with config_path.open("rb") as stream:
            raw = tomllib.load(stream)
    except FileNotFoundError as exc:
        raise ConfigurationError(f"找不到配置文件：{config_path}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigurationError(f"配置文件 TOML 格式错误：{exc}") from exc

    server = _section(raw, "server")
    database = _section(raw, "database")
    token = _required_string(server, "bearer_token", "server")
    if len(token) < 32 or token.startswith("CHANGE_ME"):
        raise ConfigurationError("server.bearer_token 必须替换为至少 32 个字符的随机令牌。")

    host = str(server.get("host", "127.0.0.1"))
    port = int(server.get("port", 8000))
    mcp_path = str(server.get("mcp_path", "/mcp"))
    if not mcp_path.startswith("/"):
        raise ConfigurationError("server.mcp_path 必须以 / 开头。")
    if not 1 <= port <= 65535:
        raise ConfigurationError("server.port 必须在 1 到 65535 之间。")

    db_port = int(database.get("port", 3306))
    if not 1 <= db_port <= 65535:
        raise ConfigurationError("database.port 必须在 1 到 65535 之间。")

    return AppConfig(
        server=ServerSettings(
            host=host,
            port=port,
            mcp_path=mcp_path,
            bearer_token=token,
            allowed_hosts=tuple(server.get("allowed_hosts", [f"{host}:{port}"])),
            allowed_origins=tuple(server.get("allowed_origins", [])),
        ),
        database=DatabaseSettings(
            host=str(database.get("host", "127.0.0.1")),
            port=db_port,
            user=_required_string(database, "user", "database"),
            password=_required_string(database, "password", "database"),
            database=_required_string(database, "database", "database"),
            connect_timeout_seconds=int(database.get("connect_timeout_seconds", 10)),
            read_timeout_seconds=int(database.get("read_timeout_seconds", 30)),
        ),
    )

