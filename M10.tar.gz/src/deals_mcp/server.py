"""Streamable HTTP MCP server entry point."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import Annotated

from mcp.server.mcpserver import MCPServer
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations
from pydantic import Field, ValidationError
from starlette.requests import Request
from starlette.responses import JSONResponse
import uvicorn

from .ad_models import (
    AdAnalysisResponse,
    AdCampaignField,
    AdCampaignsInput,
    AdNegativeTargetingField,
    AdNegativeTargetingsInput,
    AdPlacementField,
    AdPlacementsInput,
    AdPortfolioField,
    AdPortfoliosInput,
    AdProductField,
    AdProductsInput,
    AdSearchTermField,
    AdSearchTermsInput,
    AdTargetingField,
    AdTargetingsInput,
    AdToolName,
)
from .auth import BearerTokenMiddleware
from .config import AppConfig, ConfigurationError, load_config
from .models import (
    DealDetailField,
    DealId,
    GetDealItemsInput,
    GetDealItemsResponse,
    MarketId,
    OptionalDateInput,
    OptionalCountryCodeInput,
    OptionalCountryNameInput,
    OptionalMarketIdInput,
    OptionalTextInput,
    ParentAsinPerformanceField,
    ParentAsinPerformanceInput,
    ParentAsinPerformanceResponse,
    RequiredDateInput,
    SearchDealField,
    SearchDealsInput,
    SearchDealsResponse,
    VariationAsin,
)
from .repository import DealRepository, MySqlDealRepository
from .service import (
    AdAnalysisService,
    DealItemService,
    DealSearchService,
    ParentAsinPerformanceService,
    ad_analysis_validation_error_response,
    deal_item_validation_error_response,
    parent_asin_validation_error_response,
    validation_error_response,
)


LOGGER = logging.getLogger(__name__)
READ_ONLY_ANNOTATIONS = ToolAnnotations(
    title="只读查询",
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)

SEARCH_DEALS_DESCRIPTION = """查询指定站点内符合筛选条件的秒杀活动，不创建或修改任何数据。

market_id 是必填参数。deal_id 是可选筛选条件；用户指定活动 ID 时传入，否则不传。

时间参数规则：当用户使用相对时间表达时，调用工具前必须根据当前日期计算明确的
start_date 和 end_date，并以 YYYY-MM-DD 传入：
- 最近7天：包含今天，共7个自然日，即 today - 6天 至 today；
- 本周：本周一至今天；
- 上周：上周一至上周日；
- 最近30天：包含今天，共30个自然日，即 today - 29天 至 today；
- 本月：本月1日至今天；
- 上个月：上个月1日至上个月最后一天；
- 今年：当年1月1日至今天。
用户明确指定日期时，以用户日期为准。
用户没有任何时间要求时，不传 start_date 和 end_date，使用服务端默认范围。
不得把“上周”和“最近7天”、“上个月”和“最近30天”混为一谈。

returnFields 不传时，data.list 默认返回 v_e_ads_deal_info 的全部字段以及 product_count；
只有用户明确指定需要哪些数据时，才把对应字段名放入 returnFields，并只返回这些字段。
结果为结构化 JSON，
data 还包含 page、page_size、total 和 has_more。空列表表示查询成功但没有匹配活动。"""

GET_DEAL_ITEMS_DESCRIPTION = """查询指定促销/秒杀活动包含的商品，只读访问 v_e_ads_deal_detail。

deal_id 是必填参数，用户未提供时必须先询问，不能猜测。market_id、msku、start_date、
end_date 和 variation_asin 都是可选筛选条件；用户提供时传入，否则不传。相对日期换算规则与 search_deals 相同。
用户未输入起止时间时，不传 start_date 和 end_date，服务端默认查询当前月的上一个月 1 日至
下一个月最后一天。例如当前为 9 月时，默认范围是 8 月 1 日至 10 月 31 日。
page 从 1 开始；用户要求“下一页”、“更多”或“继续”时，在原条件上将 page 加 1 后再次调用。
page_size 默认 20、最大 100：只想快速看几个例子时设为 5-10；没有明确数量意图时使用 20；
明确要求“所有”、“全部”或“完整列表”时可设为 50-100。

returnFields 不传时返回 v_e_ads_deal_detail 全部字段；只有用户明确指定需要哪些数据时，
才将字段名放入 returnFields。
结果为结构化 JSON。data.total 是匹配记录总数，data.has_more 表示是否还有下一页。"""

GET_PARENT_ASIN_PERFORMANCE_DESCRIPTION = """查询父 ASIN 维度的销售表现，只读访问
v_e_ads_sales_operations_variation_asin。start_date 和 end_date 是必填参数，均为 YYYY-MM-DD；
用户未提供完整起止时间时，必须先询问用户需要查询的时间段，不能猜测、补全或使用默认时间。
variation_asin、brand、category_zh 是可选筛选条件，分别表示父 ASIN、品牌、品类（中文）；
用户提供时传入，否则不传。日期参数实际过滤数据库的 statistics_date 字段。
查询使用开始日零点（含）到结束日次日零点（不含）的范围，因此兼容数据库中的时分秒。
用户给出相对时间时，调用前按当前日期计算明确的起止日期；用户没有提供时间范围时不得调用工具。

page 从 1 开始；用户要求“下一页”、“更多”或“继续”时，在原查询条件上将 page 加 1 后再次调用。
page_size 默认 20、最大 100。returnFields 不传时返回视图全部字段；只有用户明确指定需要哪些数据时，
才将字段名放入 returnFields。结果为结构化 JSON，data.total 是总记录数，data.has_more 表示是否还有下一页。"""


def _ad_tool_description(
    display_name: str,
    view: str,
    date_field: str,
    optional_filters: str,
) -> str:
    return f"""查询{display_name}，只读访问 {view}。

variation_asin、start_date 和 end_date 均为必填参数。用户未提供父 ASIN 或完整时间范围时，
必须先询问用户，不能猜测、补全或使用默认值。start_date 和 end_date 使用 YYYY-MM-DD，
并根据数据库 {date_field} 字段检索：开始日零点（含）至结束日次日零点（不含），兼容时分秒。
可选筛选条件：{optional_filters}；用户提供时传入，否则不传。

page 从 1 开始，page_size 默认 20、最大 100。returnFields 不传时返回视图全部字段；
只有用户明确指定需要哪些数据时才传 returnFields。结果为结构化 JSON，data.total 是总记录数，
data.has_more 表示是否还有下一页。"""


AD_TOOL_DESCRIPTIONS = {
    "get_ad_portfolios": _ad_tool_description(
        "广告组合分析", "v_e_ads_portfolios_analysis", "report_date", "portfolio_id",
    ),
    "get_ad_campaigns": _ad_tool_description(
        "广告活动分析", "v_e_ads_merge_campaigns_analysis", "report_date", "campaign_id",
    ),
    "get_ad_placements": _ad_tool_description(
        "广告位分析", "v_e_ads_merge_placement_analysis", "report_date",
        "campaign_id、placement_merge",
    ),
    "get_ad_products": _ad_tool_description(
        "广告商品分析", "v_e_ads_merge_product_analysis", "report_date", "msku、market_id",
    ),
    "get_ad_targetings": _ad_tool_description(
        "广告投放分析", "v_e_ads_merge_targeting_analysis", "report_date", "market_id、target_id",
    ),
    "get_ad_negative_targetings": _ad_tool_description(
        "广告否定投放分析", "v_e_ads_merge_negative_targeting_analysis", "create_time", "market_id",
    ),
    "get_ad_search_terms": _ad_tool_description(
        "广告搜索词分析", "v_e_ads_merge_searchterm_analysis", "report_date", "market_id、query",
    ),
}

PageInput = Annotated[int, Field(ge=1, description="页码，从 1 开始。")]
PageSizeInput = Annotated[int, Field(ge=1, le=100, description="每页条数，默认 20，最大 100。")]


def create_mcp_server(repository: DealRepository) -> MCPServer:
    """Create the MCP server and register all declared deal tools."""
    server = MCPServer(
        name="deals_mcp",
        title="秒杀与广告分析 MCP",
        description="通过只读 SQL 查询秒杀活动和广告分析信息。",
        version="0.1.0",
        instructions=(
            "所有查询工具均返回结构化 JSON。向用户展示时请转换为自然语言或表格，"
            "不要展示 code/message 等内部字段。只有用户明确指定所需数据字段时才传 returnFields。"
        ),
    )
    service = DealSearchService(repository)
    item_service = DealItemService(repository)
    performance_service = ParentAsinPerformanceService(repository)
    ad_services = {
        "get_ad_portfolios": AdAnalysisService(repository, "get_ad_portfolios", "广告组合分析"),
        "get_ad_campaigns": AdAnalysisService(repository, "get_ad_campaigns", "广告活动分析"),
        "get_ad_placements": AdAnalysisService(repository, "get_ad_placements", "广告位分析"),
        "get_ad_products": AdAnalysisService(repository, "get_ad_products", "广告商品分析"),
        "get_ad_targetings": AdAnalysisService(repository, "get_ad_targetings", "广告投放分析"),
        "get_ad_negative_targetings": AdAnalysisService(
            repository, "get_ad_negative_targetings", "广告否定投放分析",
        ),
        "get_ad_search_terms": AdAnalysisService(repository, "get_ad_search_terms", "广告搜索词分析"),
    }

    async def run_ad_tool(
        tool_name: AdToolName,
        model_type,
        values: dict,
    ) -> AdAnalysisResponse:
        try:
            model_values = {
                name: value for name, value in values.items() if name in model_type.model_fields
            }
            filters = model_type(**model_values)
        except ValidationError as exc:
            return ad_analysis_validation_error_response(exc)
        return await ad_services[tool_name].get_analysis(filters)

    @server.tool(
        name="search_deals",
        title="查询秒杀活动",
        description=SEARCH_DEALS_DESCRIPTION,
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def search_deals(
        market_id: MarketId,
        deal_id: Annotated[
            OptionalTextInput,
            Field(description="促销/秒杀活动 ID，可选；不传或留空时不限制。"),
        ] = None,
        start_date: Annotated[
            OptionalDateInput,
            Field(description="活动开始日期下限（含），YYYY-MM-DD；不传或留空时默认今天往前 90 天。"),
        ] = None,
        end_date: Annotated[
            OptionalDateInput,
            Field(description="活动开始日期上限（含），YYYY-MM-DD；不传或留空时默认今天。"),
        ] = None,
        status: Annotated[
            str | None,
            Field(min_length=1, max_length=64, description="活动状态，可选；不传时不限制。"),
        ] = None,
        deal_type: Annotated[
            str | None,
            Field(min_length=1, max_length=64, description="活动类型，可选；不传时不限制。"),
        ] = None,
        returnFields: Annotated[
            list[SearchDealField] | None,
            Field(description="用户指定需要的数据字段；不传返回全部字段和 product_count。", min_length=1),
        ] = None,
        page: Annotated[
            int,
            Field(ge=1, description="页码，从 1 开始；下一页/更多/继续时在原条件上加 1。"),
        ] = 1,
        page_size: Annotated[
            int,
            Field(
                ge=1,
                le=100,
                description=(
                    "每页条数，默认 20、最大 100。看几个例子设 5-10；无明确数量设 20；"
                    "全部/完整列表设 50-100。宽泛查询应优先增加筛选条件。"
                ),
            ),
        ] = 20,
    ) -> SearchDealsResponse:
        """Execute the explicitly described search_deals MCP tool."""
        try:
            filters = SearchDealsInput(
                market_id=market_id,
                deal_id=deal_id,
                start_date=start_date,
                end_date=end_date,
                status=status,
                deal_type=deal_type,
                returnFields=returnFields,
                page=page,
                page_size=page_size,
            )
        except ValidationError as exc:
            return validation_error_response(exc)
        return await service.search(filters)

    @server.tool(
        name="get_deal_items",
        title="查询秒杀活动商品",
        description=GET_DEAL_ITEMS_DESCRIPTION,
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_deal_items(
        deal_id: DealId,
        market_id: Annotated[
            OptionalMarketIdInput,
            Field(description="站点/市场 ID，可选；不传或留空时不限制。"),
        ] = None,
        msku: Annotated[
            OptionalTextInput,
            Field(description="MSKU，可选；不传或留空时不限制。"),
        ] = None,
        start_date: Annotated[
            OptionalDateInput,
            Field(description="活动开始日期下限（含），YYYY-MM-DD；起止日期均不传时默认上月 1 日。"),
        ] = None,
        end_date: Annotated[
            OptionalDateInput,
            Field(description="活动开始日期上限（含），YYYY-MM-DD；起止日期均不传时默认下月最后一天。"),
        ] = None,
        variation_asin: Annotated[
            str | None,
            Field(min_length=1, max_length=255, description="父 ASIN，可选。"),
        ] = None,
        returnFields: Annotated[
            list[DealDetailField] | None,
            Field(description="用户指定需要的数据字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: Annotated[
            int,
            Field(ge=1, description="页码，从 1 开始；下一页/更多/继续时在原条件上加 1。"),
        ] = 1,
        page_size: Annotated[
            int,
            Field(
                ge=1,
                le=100,
                description=(
                    "每页条数，默认 20、最大 100。看几个例子设 5-10；无明确数量设 20；"
                    "全部/完整列表设 50-100。"
                ),
            ),
        ] = 20,
    ) -> GetDealItemsResponse:
        """Execute the explicitly described get_deal_items MCP tool."""
        try:
            filters = GetDealItemsInput(
                market_id=market_id,
                deal_id=deal_id,
                msku=msku,
                start_date=start_date,
                end_date=end_date,
                variation_asin=variation_asin,
                returnFields=returnFields,
                page=page,
                page_size=page_size,
            )
        except ValidationError as exc:
            return deal_item_validation_error_response(exc)
        return await item_service.get_items(filters)

    @server.tool(
        name="get_parent_asin_performance",
        title="查询父 ASIN 销售表现",
        description=GET_PARENT_ASIN_PERFORMANCE_DESCRIPTION,
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_parent_asin_performance(
        start_date: Annotated[
            RequiredDateInput,
            Field(description="统计日期范围开始（含），YYYY-MM-DD，必传；缺少时先询问用户。"),
        ],
        end_date: Annotated[
            RequiredDateInput,
            Field(description="统计日期范围结束（含），YYYY-MM-DD，必传；缺少时先询问用户。"),
        ],
        variation_asin: Annotated[
            OptionalTextInput,
            Field(description="父 ASIN，可选；不传或留空时不限制。"),
        ] = None,
        brand: Annotated[
            OptionalTextInput,
            Field(description="品牌，可选；不传或留空时不限制。"),
        ] = None,
        category_zh: Annotated[
            OptionalTextInput,
            Field(description="品类（中文），可选；不传或留空时不限制。"),
        ] = None,
        country_code: Annotated[
            OptionalCountryCodeInput,
            Field(description="国家简码；不传或留空时不限制。"),
        ] = None,
        country_name: Annotated[
            OptionalCountryNameInput,
            Field(description="国家名称；不传或留空时不限制。"),
        ] = None,
        returnFields: Annotated[
            list[ParentAsinPerformanceField] | None,
            Field(description="用户指定需要的数据字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: Annotated[
            int,
            Field(ge=1, description="页码，从 1 开始；下一页/更多/继续时在原条件上加 1。"),
        ] = 1,
        page_size: Annotated[
            int,
            Field(
                ge=1,
                le=100,
                description=(
                    "每页条数，默认 20、最大 100。某一天设 1-5；普通查询设 20；"
                    "全部/完整数据按日期范围设 50-100。"
                ),
            ),
        ] = 20,
    ) -> ParentAsinPerformanceResponse:
        """Execute the explicitly described parent-ASIN performance tool."""
        try:
            filters = ParentAsinPerformanceInput(
                variation_asin=variation_asin,
                start_date=start_date,
                end_date=end_date,
                brand=brand,
                category_zh=category_zh,
                country_code=country_code,
                country_name=country_name,
                returnFields=returnFields,
                page=page,
                page_size=page_size,
            )
        except ValidationError as exc:
            return parent_asin_validation_error_response(exc)
        return await performance_service.get_performance(filters)

    @server.tool(
        name="get_ad_portfolios",
        title="查询广告组合",
        description=AD_TOOL_DESCRIPTIONS["get_ad_portfolios"],
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_ad_portfolios(
        variation_asin: VariationAsin,
        start_date: Annotated[RequiredDateInput, Field(description="统计日期开始（含），必传。")],
        end_date: Annotated[RequiredDateInput, Field(description="统计日期结束（含），必传。")],
        portfolio_id: Annotated[
            OptionalTextInput, Field(description="广告组合 ID，可选。"),
        ] = None,
        returnFields: Annotated[
            list[AdPortfolioField] | None,
            Field(description="指定返回字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: PageInput = 1,
        page_size: PageSizeInput = 20,
    ) -> AdAnalysisResponse:
        return await run_ad_tool("get_ad_portfolios", AdPortfoliosInput, locals())

    @server.tool(
        name="get_ad_campaigns",
        title="查询广告活动",
        description=AD_TOOL_DESCRIPTIONS["get_ad_campaigns"],
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_ad_campaigns(
        variation_asin: VariationAsin,
        start_date: Annotated[RequiredDateInput, Field(description="统计日期开始（含），必传。")],
        end_date: Annotated[RequiredDateInput, Field(description="统计日期结束（含），必传。")],
        campaign_id: Annotated[
            OptionalTextInput, Field(description="广告活动 ID，可选。"),
        ] = None,
        returnFields: Annotated[
            list[AdCampaignField] | None,
            Field(description="指定返回字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: PageInput = 1,
        page_size: PageSizeInput = 20,
    ) -> AdAnalysisResponse:
        return await run_ad_tool("get_ad_campaigns", AdCampaignsInput, locals())

    @server.tool(
        name="get_ad_placements",
        title="查询广告位",
        description=AD_TOOL_DESCRIPTIONS["get_ad_placements"],
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_ad_placements(
        variation_asin: VariationAsin,
        start_date: Annotated[RequiredDateInput, Field(description="统计日期开始（含），必传。")],
        end_date: Annotated[RequiredDateInput, Field(description="统计日期结束（含），必传。")],
        campaign_id: Annotated[
            OptionalTextInput, Field(description="广告活动 ID，可选。"),
        ] = None,
        placement_merge: Annotated[
            OptionalTextInput, Field(description="标准化广告位，可选。"),
        ] = None,
        returnFields: Annotated[
            list[AdPlacementField] | None,
            Field(description="指定返回字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: PageInput = 1,
        page_size: PageSizeInput = 20,
    ) -> AdAnalysisResponse:
        return await run_ad_tool("get_ad_placements", AdPlacementsInput, locals())

    @server.tool(
        name="get_ad_products",
        title="查询广告商品",
        description=AD_TOOL_DESCRIPTIONS["get_ad_products"],
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_ad_products(
        variation_asin: VariationAsin,
        start_date: Annotated[RequiredDateInput, Field(description="统计日期开始（含），必传。")],
        end_date: Annotated[RequiredDateInput, Field(description="统计日期结束（含），必传。")],
        msku: Annotated[OptionalTextInput, Field(description="MSKU，可选。")] = None,
        market_id: Annotated[
            OptionalMarketIdInput, Field(description="站点 ID，可选。"),
        ] = None,
        returnFields: Annotated[
            list[AdProductField] | None,
            Field(description="指定返回字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: PageInput = 1,
        page_size: PageSizeInput = 20,
    ) -> AdAnalysisResponse:
        return await run_ad_tool("get_ad_products", AdProductsInput, locals())

    @server.tool(
        name="get_ad_targetings",
        title="查询广告投放",
        description=AD_TOOL_DESCRIPTIONS["get_ad_targetings"],
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_ad_targetings(
        variation_asin: VariationAsin,
        start_date: Annotated[RequiredDateInput, Field(description="统计日期开始（含），必传。")],
        end_date: Annotated[RequiredDateInput, Field(description="统计日期结束（含），必传。")],
        market_id: Annotated[
            OptionalMarketIdInput, Field(description="站点 ID，可选。"),
        ] = None,
        target_id: Annotated[
            OptionalTextInput, Field(description="投放 ID，可选。"),
        ] = None,
        returnFields: Annotated[
            list[AdTargetingField] | None,
            Field(description="指定返回字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: PageInput = 1,
        page_size: PageSizeInput = 20,
    ) -> AdAnalysisResponse:
        return await run_ad_tool("get_ad_targetings", AdTargetingsInput, locals())

    @server.tool(
        name="get_ad_negative_targetings",
        title="查询广告否定投放",
        description=AD_TOOL_DESCRIPTIONS["get_ad_negative_targetings"],
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_ad_negative_targetings(
        variation_asin: VariationAsin,
        start_date: Annotated[RequiredDateInput, Field(description="创建日期开始（含），必传。")],
        end_date: Annotated[RequiredDateInput, Field(description="创建日期结束（含），必传。")],
        market_id: Annotated[
            OptionalMarketIdInput, Field(description="站点 ID，可选。"),
        ] = None,
        returnFields: Annotated[
            list[AdNegativeTargetingField] | None,
            Field(description="指定返回字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: PageInput = 1,
        page_size: PageSizeInput = 20,
    ) -> AdAnalysisResponse:
        return await run_ad_tool(
            "get_ad_negative_targetings", AdNegativeTargetingsInput, locals(),
        )

    @server.tool(
        name="get_ad_search_terms",
        title="查询广告搜索词",
        description=AD_TOOL_DESCRIPTIONS["get_ad_search_terms"],
        annotations=READ_ONLY_ANNOTATIONS,
        structured_output=True,
    )
    async def get_ad_search_terms(
        variation_asin: VariationAsin,
        start_date: Annotated[RequiredDateInput, Field(description="统计日期开始（含），必传。")],
        end_date: Annotated[RequiredDateInput, Field(description="统计日期结束（含），必传。")],
        market_id: Annotated[
            OptionalMarketIdInput, Field(description="站点 ID，可选。"),
        ] = None,
        query: Annotated[
            OptionalTextInput, Field(description="用户搜索词，可选。"),
        ] = None,
        returnFields: Annotated[
            list[AdSearchTermField] | None,
            Field(description="指定返回字段；不传返回全部字段。", min_length=1),
        ] = None,
        page: PageInput = 1,
        page_size: PageSizeInput = 20,
    ) -> AdAnalysisResponse:
        return await run_ad_tool("get_ad_search_terms", AdSearchTermsInput, locals())

    return server


async def health(_: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "service": "deals_mcp"})


def create_app(config: AppConfig, repository: DealRepository | None = None):
    """Build the authenticated Streamable HTTP ASGI application."""
    mcp_server = create_mcp_server(repository or MySqlDealRepository(config.database))
    transport_security = TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=list(config.server.allowed_hosts),
        allowed_origins=list(config.server.allowed_origins),
    )
    app = mcp_server.streamable_http_app(
        streamable_http_path=config.server.mcp_path,
        json_response=True,
        stateless_http=True,
        transport_security=transport_security,
        host=config.server.host,
    )
    app.add_route("/health", health, methods=["GET"])
    app.add_middleware(BearerTokenMiddleware, token=config.server.bearer_token)
    return app


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行秒杀活动 Streamable HTTP MCP 服务。")
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("config.toml"),
        help="TOML 配置文件路径（默认：./config.toml）。",
    )
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        config = load_config(args.config)
    except ConfigurationError as exc:
        raise SystemExit(str(exc)) from exc
    uvicorn.run(create_app(config), host=config.server.host, port=config.server.port)


if __name__ == "__main__":
    main()
