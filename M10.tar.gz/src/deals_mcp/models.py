"""Validated input and output models for deal tools."""

from __future__ import annotations

from datetime import date
from typing import Annotated, Literal, TypeAlias

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, model_validator


SEARCH_DEAL_FIELDS = (
    "id", "market_id", "deal_id", "internal_description", "alias", "deal_type",
    "audience", "status", "workflow_status", "start_date", "end_date", "event_id",
    "event_name", "currency_code", "fee_type", "deal_fee",
    "spent_lightning_deal_fee", "order_product_sales", "unit_sales", "deal_inventory",
    "sales_rate", "glance_views", "conversion_rate", "fee_rate", "record_time",
    "update_time", "sys_etl_time", "team_code", "product_count",
)

DEAL_DETAIL_FIELDS = (
    "id", "market_id", "deal_id", "title", "asin", "msku", "currency_code",
    "adjust_standard_price", "price", "category_min_zh", "listing_tag", "spu", "sku",
    "seller", "deal_inventory", "order_product_sales", "glance_views",
    "internal_description", "alias", "deal_type", "start_date", "end_date", "event_name",
    "deal_fee", "sys_etl_time", "team_code", "variation_asin",
)

PARENT_ASIN_PERFORMANCE_FIELDS = (
    "statistics_date", "variation_asin", "spu", "product_name", "category_zh", "brand",
    "country_code", "country_name", "sale_price", "units_ordered",
    "sales_gross_profit_rate", "sales_net_profit", "sales_net_profit_rate", "refund_rate",
    "return_rate", "main_category", "main_category_rank", "sub_category",
    "sub_category_rank", "ads_impressions", "ads_clicks", "ctr", "ads_orders", "ads_cvr",
    "cpc", "cpa", "acos", "acoas", "asoas", "natural_order_rate", "order_cvr",
    "product_manager_account_id", "selling_manager_id", "product_manager_account_name",
    "selling_manager_name", "listing_state", "listing_level", "team_code", "sys_etl_time",
)

SearchDealField = Literal[*SEARCH_DEAL_FIELDS]
DealDetailField = Literal[*DEAL_DETAIL_FIELDS]
ParentAsinPerformanceField = Literal[*PARENT_ASIN_PERFORMANCE_FIELDS]
JsonScalar: TypeAlias = str | int | float | bool | None
JsonRecord: TypeAlias = dict[str, JsonScalar]


MarketId = Annotated[
    int,
    Field(ge=1, description="站点/市场 ID，必传，为正整数，例如 187 或 330。"),
]
DealId = Annotated[
    str,
    Field(min_length=1, max_length=128, description="促销/秒杀活动 ID，必传；用户未提供时应先询问。"),
]
VariationAsin = Annotated[
    str,
    Field(min_length=1, max_length=64, description="父 ASIN，必传；用户未提供时应先询问。"),
]


def _blank_string_to_none(value: object) -> object:
    if isinstance(value, str) and not value.strip():
        return None
    return value


OptionalDateInput = Annotated[date | None, BeforeValidator(_blank_string_to_none)]
RequiredDateInput = Annotated[date, BeforeValidator(_blank_string_to_none)]
OptionalMarketIdInput = Annotated[
    Annotated[int, Field(ge=1)] | None,
    BeforeValidator(_blank_string_to_none),
]
OptionalTextInput = Annotated[
    Annotated[str, Field(min_length=1, max_length=255)] | None,
    BeforeValidator(_blank_string_to_none),
]
OptionalCountryCodeInput = Annotated[
    Annotated[str, Field(min_length=1, max_length=32)] | None,
    BeforeValidator(_blank_string_to_none),
]
OptionalCountryNameInput = Annotated[
    Annotated[str, Field(min_length=1, max_length=128)] | None,
    BeforeValidator(_blank_string_to_none),
]
class SearchDealsInput(BaseModel):
    """Validated search filters passed to the repository."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    market_id: MarketId
    deal_id: OptionalTextInput = Field(
        default=None,
        description="促销/秒杀活动 ID，可选；不传或留空时不限制。",
    )
    start_date: OptionalDateInput = Field(
        default=None,
        description=(
            "活动开始日期下限（含），YYYY-MM-DD；起止日期均不传时默认当前月的上一个月 1 日。"
        ),
    )
    end_date: OptionalDateInput = Field(
        default=None,
        description=(
            "活动开始日期上限（含），YYYY-MM-DD；起止日期均不传时默认当前月的下一个月最后一天。"
        ),
    )
    status: OptionalTextInput = Field(default=None, description="活动状态，可选；不传时不限制。")
    deal_type: OptionalTextInput = Field(default=None, description="活动类型，可选；不传时不限制。")
    returnFields: list[SearchDealField] | None = Field(
        default=None,
        min_length=1,
        description="用户指定需要的数据字段时传入；不传时返回秒杀信息表全部字段和 product_count。",
    )
    page: int = Field(default=1, ge=1, description="页码，从 1 开始。")
    page_size: int = Field(default=20, ge=1, le=100, description="每页条数，默认 20，最大 100。")

    @model_validator(mode="after")
    def validate_date_range(self) -> "SearchDealsInput":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("start_date 不能晚于 end_date。")
        return self


class SearchDealsData(BaseModel):
    list: list[JsonRecord]
    page: int
    page_size: int
    total: int
    has_more: bool


class SearchDealsResponse(BaseModel):
    code: int
    message: str
    data: SearchDealsData | None = None


class GetDealItemsInput(BaseModel):
    """Validated filters for querying products in one deal."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    deal_id: DealId
    market_id: OptionalMarketIdInput = Field(
        default=None,
        description="站点/市场 ID，可选；不传或留空时不限制。",
    )
    msku: OptionalTextInput = Field(
        default=None,
        description="MSKU，可选；不传或留空时不限制。",
    )
    start_date: OptionalDateInput = Field(
        default=None,
        description="活动开始日期下限（含），YYYY-MM-DD；不传时默认为今天往前 90 天。",
    )
    end_date: OptionalDateInput = Field(
        default=None,
        description="活动开始日期上限（含），YYYY-MM-DD；不传时默认为今天。",
    )
    variation_asin: OptionalTextInput = Field(default=None, description="父 ASIN，可选；不传时不限制。")
    returnFields: list[DealDetailField] | None = Field(
        default=None,
        min_length=1,
        description="用户指定需要的数据字段时传入；不传时返回秒杀商品明细表全部字段。",
    )
    page: int = Field(default=1, ge=1, description="页码，从 1 开始。")
    page_size: int = Field(default=20, ge=1, le=100, description="每页条数，默认 20，最大 100。")

    @model_validator(mode="after")
    def validate_date_range(self) -> "GetDealItemsInput":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("start_date 不能晚于 end_date。")
        return self


class GetDealItemsData(BaseModel):
    list: list[JsonRecord]
    page: int
    page_size: int
    total: int
    has_more: bool


class GetDealItemsResponse(BaseModel):
    code: int
    message: str
    data: GetDealItemsData | None = None


class ParentAsinPerformanceInput(BaseModel):
    """Validated date-range filters for parent-ASIN performance."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    start_date: RequiredDateInput = Field(
        description="统计日期范围开始（含），YYYY-MM-DD，必传；用户未提供时必须先询问。",
    )
    end_date: RequiredDateInput = Field(
        description="统计日期范围结束（含），YYYY-MM-DD，必传；用户未提供时必须先询问。",
    )
    variation_asin: OptionalTextInput = Field(
        default=None,
        description="父 ASIN，可选；不传或留空时不限制。",
    )
    brand: OptionalTextInput = Field(
        default=None,
        description="品牌，可选；不传或留空时不限制。",
    )
    category_zh: OptionalTextInput = Field(
        default=None,
        description="品类（中文），可选；不传或留空时不限制。",
    )
    country_code: OptionalCountryCodeInput = Field(default=None, description="国家简码，可选。")
    country_name: OptionalCountryNameInput = Field(default=None, description="国家名称，可选。")
    returnFields: list[ParentAsinPerformanceField] | None = Field(
        default=None,
        min_length=1,
        description="用户指定需要的数据字段时传入；不传时返回父 ASIN 销售表现表全部字段。",
    )
    page: int = Field(default=1, ge=1, description="页码，从 1 开始。")
    page_size: int = Field(default=20, ge=1, le=100, description="每页条数，默认 20，最大 100。")

    @model_validator(mode="after")
    def validate_date_range(self) -> "ParentAsinPerformanceInput":
        if self.start_date > self.end_date:
            raise ValueError("start_date 不能晚于 end_date。")
        return self


class ParentAsinPerformanceData(BaseModel):
    list: list[JsonRecord]
    page: int
    page_size: int
    total: int
    has_more: bool


class ParentAsinPerformanceResponse(BaseModel):
    code: int
    message: str
    data: ParentAsinPerformanceData | None = None
