"""Validated contracts and DDL field allowlists for advertising analysis tools."""

from __future__ import annotations

from typing import Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .models import (
    JsonRecord,
    OptionalMarketIdInput,
    OptionalTextInput,
    RequiredDateInput,
    VariationAsin,
)


AD_PORTFOLIO_FIELDS = (
    "report_date", "market_id", "alias", "country_code", "team_code", "portfolio_id",
    "portfolio_name", "variation_asin", "currency", "serving_status",
    "shared_remaining_campaign_budget", "campaign_count", "total_campaign_budget",
    "impressions", "viewable_impressions", "clicks", "ctr_pct", "detail_page_views",
    "cost", "cpc", "vcpm", "cpv", "spc", "video5_second_views",
    "video5_second_view_rate_pct", "video_complete_views", "video_first_quartile_views",
    "video_midpoint_views", "video_third_quartile_views", "video_unmutes", "vtr_pct",
    "vctr_pct", "dpv", "dpvr_pct", "attributed_sales_merge", "direct_sales_merge",
    "indirect_sales_merge", "acos_pct", "roas", "attributed_conversions_merge",
    "direct_orders_merge", "indirect_orders_merge", "indirect_order_ratio_pct", "cvr_pct",
    "cpa", "avg_order_value", "ads_unit_sales_merge", "direct_units_merge",
    "indirect_units_merge", "new_buyer_orders_merge", "new_buyer_order_ratio_pct",
    "new_buyer_sales_merge", "new_buyer_sales_ratio_pct", "same_sku_acos_pct",
    "budget_amount", "budget_policy", "budget_currency_code", "budget_start_date",
    "budget_end_date", "sys_etl_time",
)

AD_CAMPAIGN_FIELDS = (
    "campaign_id", "market_id", "alias", "country_code", "team_code", "portfolio_id",
    "portfolio_name", "variation_asin", "report_date", "ads_type",
    "group_targeting_type", "campaign_name", "campaign_state", "currency",
    "serving_status", "daily_budget", "original_budget", "site_restrictions",
    "bid_strategy", "start_date", "end_date", "cost_type", "tags", "impressions",
    "viewable_impressions", "clicks", "ctr_pct", "detail_page_views", "cost", "cpc",
    "vcpm", "cpv", "spc", "video5_second_views", "video5_second_view_rate_pct",
    "video_complete_views", "video_first_quartile_views", "video_midpoint_views",
    "video_third_quartile_views", "video_unmutes", "vtr_pct", "vctr_pct",
    "top_of_search_impression_share", "dpv", "dpvr_pct", "attributed_sales_merge",
    "direct_sales_merge", "indirect_sales_merge", "acos_pct", "roas",
    "attributed_conversions_merge", "direct_orders_merge", "indirect_orders_merge",
    "indirect_order_ratio_pct", "cvr_pct", "cpa", "avg_order_value",
    "ads_unit_sales_merge", "direct_units_merge", "indirect_units_merge",
    "new_buyer_orders_merge", "new_buyer_order_ratio_pct", "new_buyer_sales_merge",
    "new_buyer_sales_ratio_pct", "same_sku_acos_pct", "sys_etl_time",
)

AD_PLACEMENT_FIELDS = (
    "campaign_id", "market_id", "alias", "country_code", "team_code", "portfolio_id",
    "portfolio_name", "variation_asin", "report_date", "ads_type",
    "group_targeting_type", "campaign_name", "placement", "placement_merge",
    "campaign_state", "currency", "serving_status", "daily_budget", "original_budget",
    "site_restrictions", "bid_strategy", "start_date", "end_date", "cost_type", "tags",
    "impressions", "viewable_impressions", "clicks", "ctr_pct", "detail_page_views",
    "cost", "cpc", "vcpm", "cpv", "spc", "video5_second_views",
    "video5_second_view_rate_pct", "video_complete_views", "video_first_quartile_views",
    "video_midpoint_views", "video_third_quartile_views", "video_unmutes", "vtr_pct",
    "vctr_pct", "dpv", "dpvr_pct", "attributed_sales_merge", "direct_sales_merge",
    "indirect_sales_merge", "acos_pct", "roas", "attributed_conversions_merge",
    "direct_orders_merge", "indirect_orders_merge", "indirect_order_ratio_pct", "cvr_pct",
    "cpa", "avg_order_value", "ads_unit_sales_merge", "direct_units_merge",
    "indirect_units_merge", "new_buyer_orders_merge", "new_buyer_order_ratio_pct",
    "new_buyer_sales_merge", "new_buyer_sales_ratio_pct", "same_sku_acos_pct",
    "sys_etl_time",
)

AD_PRODUCT_FIELDS = (
    "report_date", "market_id", "alias", "team_code", "country_code", "ad_account",
    "listing_title", "asin", "msku", "spu", "spu_name", "variation_asin",
    "adjust_standard_price", "currency", "active_ad_count", "impressions",
    "viewable_impressions", "clicks", "ctr_pct", "detail_page_views", "cost", "cpc",
    "vcpm", "spc", "video_complete_views", "video_first_quartile_views",
    "video_midpoint_views", "video_third_quartile_views", "video_unmutes", "vtr_pct",
    "vctr_pct", "dpv", "dpvr_pct", "attributed_sales_merge", "direct_sales_merge",
    "indirect_sales_merge", "acos_pct", "roas", "attributed_conversions_merge",
    "direct_orders_merge", "ad_order_ratio_pct", "indirect_orders_merge",
    "indirect_order_ratio_pct", "cvr_pct", "cpa", "avg_order_value",
    "ads_unit_sales_merge", "direct_units_merge", "indirect_units_merge",
    "new_buyer_orders_merge", "new_buyer_order_ratio_pct", "new_buyer_sales_merge",
    "new_buyer_sales_ratio_pct", "acoas_pct", "asoas_pct", "total_orders",
    "total_product_sales", "same_sku_acos_pct", "sys_etl_time",
)

AD_TARGETING_FIELDS = (
    "campaign_id", "market_id", "alias", "country_code", "team_code", "group_id",
    "group_name", "variation_asin", "currency", "ad_account", "create_time", "target_id",
    "targeting_text", "report_date", "ads_type", "target_type", "campaign_name",
    "target_state", "serving_status", "merge_match_type", "bid", "impressions",
    "viewable_impressions", "clicks", "ctr_pct", "detail_page_views", "cost", "cpc",
    "vcpm", "cpv", "spc", "video5_second_views", "video5_second_view_rate_pct",
    "video_complete_views", "video_first_quartile_views", "video_midpoint_views",
    "video_third_quartile_views", "video_unmutes", "vtr_pct", "vctr_pct",
    "top_of_search_impression_share", "dpv", "dpvr_pct", "attributed_sales_merge",
    "direct_sales_merge", "indirect_sales_merge", "acos_pct", "roas",
    "attributed_conversions_merge", "direct_orders_merge", "indirect_orders_merge",
    "indirect_order_ratio_pct", "cvr_pct", "cpa", "avg_order_value",
    "ads_unit_sales_merge", "direct_units_merge", "indirect_units_merge",
    "new_buyer_orders_merge", "new_buyer_order_ratio_pct", "new_buyer_sales_merge",
    "new_buyer_sales_ratio_pct", "same_sku_acos_pct", "sys_etl_time", "suggest_bid",
    "suggest_max_bid", "suggest_min_bid", "aba_rank_day",
)

AD_NEGATIVE_TARGETING_FIELDS = (
    "market_id", "alias", "country_code", "ad_account", "campaign_id", "campaign_name",
    "group_id", "group_name", "portfolio_id", "portfolio_name", "expression_name",
    "ads_type", "merge_match_type", "serving_status", "range_type", "state",
    "sys_etl_time", "create_time", "variation_asin", "team_code",
)

AD_SEARCH_TERM_FIELDS = (
    "campaign_id", "market_id", "alias", "country_code", "team_code", "group_id",
    "group_name", "portfolio_id", "portfolio_name", "variation_asin", "currency",
    "ad_account", "create_time", "targeting_text", "query", "report_date", "state",
    "listing_title", "targeting_type", "ads_type", "target_type", "campaign_name",
    "merge_match_type", "bid", "suggest_bid", "suggest_max_bid", "suggest_min_bid",
    "aba_rank_day", "first_search_time", "impressions", "viewable_impressions", "clicks",
    "ctr_pct", "cost", "cpc", "vcpm", "cpv", "spc", "video5_second_views",
    "video5_second_view_rate_pct", "video_complete_views", "video_first_quartile_views",
    "video_midpoint_views", "video_third_quartile_views", "video_unmutes", "vtr_pct",
    "vctr_pct", "dpv", "dpvr_pct", "attributed_sales_merge", "direct_sales_merge",
    "indirect_sales_merge", "acos_pct", "roas", "attributed_conversions_merge",
    "direct_orders_merge", "indirect_orders_merge", "indirect_order_ratio_pct", "cvr_pct",
    "cpa", "avg_order_value", "ads_unit_sales_merge", "direct_units_merge",
    "indirect_units_merge", "new_buyer_orders_merge", "new_buyer_order_ratio_pct",
    "new_buyer_sales_merge", "new_buyer_sales_ratio_pct", "same_sku_acos_pct",
    "sys_etl_time",
)

AdToolName = Literal[
    "get_ad_portfolios",
    "get_ad_campaigns",
    "get_ad_placements",
    "get_ad_products",
    "get_ad_targetings",
    "get_ad_negative_targetings",
    "get_ad_search_terms",
]
AdPortfolioField = Literal[*AD_PORTFOLIO_FIELDS]
AdCampaignField = Literal[*AD_CAMPAIGN_FIELDS]
AdPlacementField = Literal[*AD_PLACEMENT_FIELDS]
AdProductField = Literal[*AD_PRODUCT_FIELDS]
AdTargetingField = Literal[*AD_TARGETING_FIELDS]
AdNegativeTargetingField = Literal[*AD_NEGATIVE_TARGETING_FIELDS]
AdSearchTermField = Literal[*AD_SEARCH_TERM_FIELDS]

AD_ANALYSIS_FIELDS: dict[str, tuple[str, ...]] = {
    "get_ad_portfolios": AD_PORTFOLIO_FIELDS,
    "get_ad_campaigns": AD_CAMPAIGN_FIELDS,
    "get_ad_placements": AD_PLACEMENT_FIELDS,
    "get_ad_products": AD_PRODUCT_FIELDS,
    "get_ad_targetings": AD_TARGETING_FIELDS,
    "get_ad_negative_targetings": AD_NEGATIVE_TARGETING_FIELDS,
    "get_ad_search_terms": AD_SEARCH_TERM_FIELDS,
}


class AdAnalysisInputBase(BaseModel):
    """Shared required filters and pagination for advertising views."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    variation_asin: VariationAsin
    start_date: RequiredDateInput = Field(
        description="查询日期范围开始（含），YYYY-MM-DD，必传；用户未提供时必须先询问。",
    )
    end_date: RequiredDateInput = Field(
        description="查询日期范围结束（含），YYYY-MM-DD，必传；用户未提供时必须先询问。",
    )
    page: int = Field(default=1, ge=1, description="页码，从 1 开始。")
    page_size: int = Field(default=20, ge=1, le=100, description="每页条数，默认 20，最大 100。")

    @model_validator(mode="after")
    def validate_date_range(self) -> "AdAnalysisInputBase":
        if self.start_date > self.end_date:
            raise ValueError("start_date 不能晚于 end_date。")
        return self


class AdPortfoliosInput(AdAnalysisInputBase):
    portfolio_id: OptionalTextInput = Field(default=None, description="广告组合 ID，可选。")
    returnFields: list[AdPortfolioField] | None = Field(
        default=None, min_length=1, description="指定返回字段；不传返回视图全部字段。",
    )


class AdCampaignsInput(AdAnalysisInputBase):
    campaign_id: OptionalTextInput = Field(default=None, description="广告活动 ID，可选。")
    returnFields: list[AdCampaignField] | None = Field(
        default=None, min_length=1, description="指定返回字段；不传返回视图全部字段。",
    )


class AdPlacementsInput(AdAnalysisInputBase):
    campaign_id: OptionalTextInput = Field(default=None, description="广告活动 ID，可选。")
    placement_merge: OptionalTextInput = Field(default=None, description="标准化广告位，可选。")
    returnFields: list[AdPlacementField] | None = Field(
        default=None, min_length=1, description="指定返回字段；不传返回视图全部字段。",
    )


class AdProductsInput(AdAnalysisInputBase):
    msku: OptionalTextInput = Field(default=None, description="MSKU，可选。")
    market_id: OptionalMarketIdInput = Field(default=None, description="站点 ID，可选。")
    returnFields: list[AdProductField] | None = Field(
        default=None, min_length=1, description="指定返回字段；不传返回视图全部字段。",
    )


class AdTargetingsInput(AdAnalysisInputBase):
    market_id: OptionalMarketIdInput = Field(default=None, description="站点 ID，可选。")
    target_id: OptionalTextInput = Field(default=None, description="投放 ID，可选。")
    returnFields: list[AdTargetingField] | None = Field(
        default=None, min_length=1, description="指定返回字段；不传返回视图全部字段。",
    )


class AdNegativeTargetingsInput(AdAnalysisInputBase):
    market_id: OptionalMarketIdInput = Field(default=None, description="站点 ID，可选。")
    returnFields: list[AdNegativeTargetingField] | None = Field(
        default=None, min_length=1, description="指定返回字段；不传返回视图全部字段。",
    )


class AdSearchTermsInput(AdAnalysisInputBase):
    market_id: OptionalMarketIdInput = Field(default=None, description="站点 ID，可选。")
    query: OptionalTextInput = Field(default=None, description="用户搜索词，可选。")
    returnFields: list[AdSearchTermField] | None = Field(
        default=None, min_length=1, description="指定返回字段；不传返回视图全部字段。",
    )


AdAnalysisInput: TypeAlias = (
    AdPortfoliosInput
    | AdCampaignsInput
    | AdPlacementsInput
    | AdProductsInput
    | AdTargetingsInput
    | AdNegativeTargetingsInput
    | AdSearchTermsInput
)


class AdAnalysisData(BaseModel):
    list: list[JsonRecord]
    page: int
    page_size: int
    total: int
    has_more: bool


class AdAnalysisResponse(BaseModel):
    code: int
    message: str
    data: AdAnalysisData | None = None
