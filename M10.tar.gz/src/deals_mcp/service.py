"""Deal search application service."""

from __future__ import annotations

import logging

import pymysql
from pydantic import ValidationError

from .ad_models import AdAnalysisData, AdAnalysisInput, AdAnalysisResponse, AdToolName
from .models import (
    GetDealItemsData,
    GetDealItemsInput,
    GetDealItemsResponse,
    ParentAsinPerformanceData,
    ParentAsinPerformanceInput,
    ParentAsinPerformanceResponse,
    SearchDealsData,
    SearchDealsInput,
    SearchDealsResponse,
)
from .repository import DealRepository


LOGGER = logging.getLogger(__name__)


class DealSearchService:
    def __init__(self, repository: DealRepository) -> None:
        self._repository = repository

    async def search(self, filters: SearchDealsInput) -> SearchDealsResponse:
        try:
            result = await self._repository.search(filters)
        except (pymysql.MySQLError, OSError, TimeoutError):
            LOGGER.exception("Deal search database operation failed")
            return SearchDealsResponse(
                code=500,
                message="秒杀活动查询失败，请检查数据库连接和查询权限后重试。",
            )

        return SearchDealsResponse(
            code=200,
            message="success",
            data=SearchDealsData(
                list=result.items,
                page=filters.page,
                page_size=filters.page_size,
                total=result.total,
                has_more=filters.page * filters.page_size < result.total,
            ),
        )


class DealItemService:
    def __init__(self, repository: DealRepository) -> None:
        self._repository = repository

    async def get_items(self, filters: GetDealItemsInput) -> GetDealItemsResponse:
        try:
            result = await self._repository.get_items(filters)
        except (pymysql.MySQLError, OSError, TimeoutError):
            LOGGER.exception("Deal item database operation failed")
            return GetDealItemsResponse(
                code=500,
                message="秒杀活动商品查询失败，请检查数据库连接和查询权限后重试。",
            )

        return GetDealItemsResponse(
            code=200,
            message="success",
            data=GetDealItemsData(
                list=result.items,
                page=filters.page,
                page_size=filters.page_size,
                total=result.total,
                has_more=filters.page * filters.page_size < result.total,
            ),
        )


class ParentAsinPerformanceService:
    def __init__(self, repository: DealRepository) -> None:
        self._repository = repository

    async def get_performance(
        self,
        filters: ParentAsinPerformanceInput,
    ) -> ParentAsinPerformanceResponse:
        try:
            result = await self._repository.get_parent_asin_performance(filters)
        except (pymysql.MySQLError, OSError, TimeoutError, ValueError, TypeError):
            LOGGER.exception("Parent ASIN performance database operation failed")
            return ParentAsinPerformanceResponse(
                code=500,
                message="父 ASIN 销售表现查询失败，请检查数据库连接和查询权限后重试。",
            )

        return ParentAsinPerformanceResponse(
            code=200,
            message="success",
            data=ParentAsinPerformanceData(
                list=result.items,
                page=filters.page,
                page_size=filters.page_size,
                total=result.total,
                has_more=filters.page * filters.page_size < result.total,
            ),
        )


class AdAnalysisService:
    def __init__(
        self,
        repository: DealRepository,
        tool_name: AdToolName,
        display_name: str,
    ) -> None:
        self._repository = repository
        self._tool_name = tool_name
        self._display_name = display_name

    async def get_analysis(self, filters: AdAnalysisInput) -> AdAnalysisResponse:
        try:
            result = await self._repository.get_ad_analysis(self._tool_name, filters)
        except (pymysql.MySQLError, OSError, TimeoutError, ValueError, TypeError):
            LOGGER.exception("Advertising analysis database operation failed: %s", self._tool_name)
            return AdAnalysisResponse(
                code=500,
                message=f"{self._display_name}查询失败，请检查数据库连接和查询权限后重试。",
            )

        return AdAnalysisResponse(
            code=200,
            message="success",
            data=AdAnalysisData(
                list=result.items,
                page=filters.page,
                page_size=filters.page_size,
                total=result.total,
                has_more=filters.page * filters.page_size < result.total,
            ),
        )


def validation_error_response(exc: ValidationError) -> SearchDealsResponse:
    first_error = exc.errors(include_url=False)[0]
    location = ".".join(str(part) for part in first_error["loc"])
    return SearchDealsResponse(
        code=400,
        message=f"查询参数无效（{location}）：{first_error['msg']}",
    )


def deal_item_validation_error_response(exc: ValidationError) -> GetDealItemsResponse:
    first_error = exc.errors(include_url=False)[0]
    location = ".".join(str(part) for part in first_error["loc"])
    return GetDealItemsResponse(
        code=400,
        message=f"查询参数无效（{location}）：{first_error['msg']}",
    )


def parent_asin_validation_error_response(
    exc: ValidationError,
) -> ParentAsinPerformanceResponse:
    first_error = exc.errors(include_url=False)[0]
    location = ".".join(str(part) for part in first_error["loc"])
    return ParentAsinPerformanceResponse(
        code=400,
        message=f"查询参数无效（{location}）：{first_error['msg']}",
    )


def ad_analysis_validation_error_response(exc: ValidationError) -> AdAnalysisResponse:
    first_error = exc.errors(include_url=False)[0]
    location = ".".join(str(part) for part in first_error["loc"])
    return AdAnalysisResponse(
        code=400,
        message=f"查询参数无效（{location}）：{first_error['msg']}",
    )
