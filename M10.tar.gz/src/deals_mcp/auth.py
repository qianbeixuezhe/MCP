"""Bearer token authentication middleware."""

from __future__ import annotations

import secrets

from starlette.datastructures import Headers
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send


class BearerTokenMiddleware:
    """Require a configured bearer token for every MCP request."""

    def __init__(self, app: ASGIApp, token: str, exempt_paths: tuple[str, ...] = ("/health",)) -> None:
        self._app = app
        self._token = token
        self._exempt_paths = frozenset(exempt_paths)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope.get("path") in self._exempt_paths:
            await self._app(scope, receive, send)
            return

        authorization = Headers(scope=scope).get("authorization", "")
        scheme, separator, supplied_token = authorization.partition(" ")
        authenticated = (
            separator == " "
            and scheme.lower() == "bearer"
            and secrets.compare_digest(supplied_token, self._token)
        )
        if not authenticated:
            response = JSONResponse(
                {"error": "unauthorized", "message": "缺少或无效的 Bearer Token。"},
                status_code=401,
                headers={"WWW-Authenticate": "Bearer"},
            )
            await response(scope, receive, send)
            return

        await self._app(scope, receive, send)

