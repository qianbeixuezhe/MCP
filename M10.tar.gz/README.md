# 秒杀与广告分析 MCP 服务

基于 Python MCP SDK 2.x 的只读 Streamable HTTP 服务。当前完整实现：

- `search_deals`
- `get_deal_items`
- `get_parent_asin_performance`
- `get_ad_portfolios`
- `get_ad_campaigns`
- `get_ad_placements`
- `get_ad_products`
- `get_ad_targetings`
- `get_ad_negative_targetings`
- `get_ad_search_terms`

## 安装

要求 Python 3.11+。数据库用户只授予本服务使用的 10 个视图的 `SELECT` 权限：

- `v_e_ads_deal_info`
- `v_e_ads_deal_detail`
- `v_e_ads_sales_operations_variation_asin`
- `v_e_ads_portfolios_analysis`
- `v_e_ads_merge_campaigns_analysis`
- `v_e_ads_merge_placement_analysis`
- `v_e_ads_merge_product_analysis`
- `v_e_ads_merge_targeting_analysis`
- `v_e_ads_merge_negative_targeting_analysis`
- `v_e_ads_merge_searchterm_analysis`

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e .
```

项目已包含可运行的 `config.toml`，其中 Bearer Token 为本地随机生成值。部署前应重新生成并替换：

```powershell
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

数据库默认配置为 `127.0.0.1:3306`、用户 `root`、空密码、数据库 `ai_db`。生产环境请使用专用只读数据库账号。

## 运行

```powershell
python -m deals_mcp.server --config .\config.toml
```

安装为命令后也可运行：

```powershell
deals-mcp --config .\config.toml
```

- MCP URL：`http://127.0.0.1:8001/mcp`
- 健康检查：`http://127.0.0.1:8001/health`
- 请求头：`Authorization: Bearer <config.toml 中的 bearer_token>`

如通过域名、反向代理或其他端口访问，必须同步更新 `allowed_hosts` 和 `allowed_origins`，否则 DNS 重绑定防护会拒绝请求。

## Docker 部署

服务器需要安装 Docker Engine 和 Docker Compose 插件。镜像不会包含 `config.toml`；
Compose 会在启动时将服务器本地的配置文件作为只读 secret 挂载到容器。
Nginx 对外监听 80，MCP 的 8001 仅绑定服务器本机，避免绕过网关直接暴露服务。

腾讯云服务器先配置官方 Docker Hub 内网镜像。在保留 `/etc/docker/daemon.json`
其他配置的前提下，将 `registry-mirrors` 设置为：

```json
{
  "registry-mirrors": [
    "https://mirror.ccs.tencentyun.com"
  ]
}
```

然后重启并验证 Docker：

```bash
systemctl daemon-reload
systemctl restart docker
docker info 2>/dev/null | sed -n '/Registry Mirrors/,+3p'
docker pull python:3.12-slim
docker pull nginx:1.28-alpine
```

Dockerfile 已将 Debian 和 PyPI 下载源分别切换至腾讯云软件源，Compose 构建参数中可按需替换。

首次部署时创建配置：

```bash
cp config.example.toml config.toml
nano config.toml
```

使用公网 IP 通过 Nginx 访问时，`[server]` 至少应包含：

```toml
host = "0.0.0.0"
port = 8001
allowed_hosts = ["175.178.225.178", "175.178.225.178:8001", "127.0.0.1:8001", "localhost:8001"]
allowed_origins = ["http://175.178.225.178", "http://175.178.225.178:8001", "http://127.0.0.1:8001", "http://localhost:8001"]
```

构建并启动：

```bash
docker compose config
docker compose up -d --build
docker compose ps
docker compose logs -f deals-mcp
docker compose logs -f nginx
```

验证：

```bash
curl http://127.0.0.1:8001/health
curl http://175.178.225.178/health
```

公网 MCP 地址为 `http://175.178.225.178/mcp`。腾讯云安全组只需对外开放 TCP 80；
不需要开放 8001。正式环境仍建议配置域名和 HTTPS。

停止服务：

```bash
docker compose down
```

### 不使用 Git 上传到服务器

以下命令在本机项目目录中执行，将源码打包但排除虚拟环境、缓存和真实配置：

```powershell
tar --exclude=*.egg-info --exclude=__pycache__ -czf ..\deals_mcp_server.tar.gz Dockerfile compose.yaml nginx .dockerignore .gitignore config.example.toml pyproject.toml README.md src
scp ..\deals_mcp_server.tar.gz root@175.178.225.178:/tmp/
```

以上以 `root` 为服务器账号；如果实际账号是 `ubuntu` 等，请替换命令中的 `root`。
随后通过 SSH 登录服务器并部署：

```bash
ssh root@175.178.225.178
mkdir -p /opt/deals_mcp_server
tar -xzf /tmp/deals_mcp_server.tar.gz -C /opt/deals_mcp_server
cd /opt/deals_mcp_server
cp config.example.toml config.toml
nano config.toml
docker compose config
docker compose up -d --build
docker compose ps
```

也可以使用 WinSCP/SFTP 将项目目录上传到 `/opt/deals_mcp_server`。上传时不要包含
`.venv`、`.idea`、`__pycache__` 和本机的 `config.toml`；服务器上应单独创建生产配置。

## `search_deals`

输入：

| 参数 | 必填 | 默认值 | 说明 |
|---|---:|---:|---|
| `market_id` | 是 | - | 正整数站点/市场 ID，例如 `187`、`330` |
| `deal_id` | 否 | 不限制 | 促销/秒杀活动 ID；留空等同未传 |
| `start_date` | 否 | 今天前 90 天 | `YYYY-MM-DD`，按活动开始时间筛选；留空等同未传 |
| `end_date` | 否 | 今天 | `YYYY-MM-DD`，含当天；留空等同未传 |
| `status` | 否 | 不限制 | 活动状态 |
| `deal_type` | 否 | 不限制 | 活动类型 |
| `returnFields` | 否 | 全部字段 | 仅当用户指定需要哪些数据时传入字段名数组 |
| `page` | 否 | 1 | 从 1 开始 |
| `page_size` | 否 | 20 | 1-100 |

默认返回 `v_e_ads_deal_info` DDL 中全部字段，并额外返回 `product_count`。
`product_count` 通过 `deal_id + market_id` 从 `v_e_ads_deal_detail` 统计不同 ASIN。
SQL 使用固定字段白名单和参数绑定，不接受调用方传入 SQL 或任意列名。

## `get_deal_items`

查询指定促销/秒杀活动包含的商品，可按市场和 MSKU 进一步筛选。

| 参数 | 必填 | 默认值 | 说明 |
|---|---:|---:|---|
| `deal_id` | 是 | - | 促销/秒杀活动 ID；用户未提供时应先询问 |
| `market_id` | 否 | 不限制 | 正整数站点/市场 ID；留空等同未传 |
| `msku` | 否 | 不限制 | MSKU；留空等同未传 |
| `start_date` | 否 | 上月 1 日 | `YYYY-MM-DD`，按活动开始时间筛选 |
| `end_date` | 否 | 下月最后一天 | `YYYY-MM-DD`，包含当天 |
| `variation_asin` | 否 | 不限制 | 父 ASIN |
| `returnFields` | 否 | 全部字段 | 仅当用户指定需要哪些数据时传入字段名数组 |
| `page` | 否 | 1 | 从 1 开始；下一页、更多或继续时加 1 |
| `page_size` | 否 | 20 | 1-100；少量示例用 5-10，完整列表可用 50-100 |

默认返回 `v_e_ads_deal_detail` DDL 中全部字段。金额以精确十进制字符串返回，日期保留时分秒，
数据库中的空值返回 `null`。查询值全部使用绑定参数，字段选择只接受预定义白名单。
起止日期都不传时，以服务器当前日期计算范围：当前月的上一个月 1 日至下一个月最后一天；
例如当前为 9 月时，默认查询 8 月 1 日至 10 月 31 日。

## `get_parent_asin_performance`

按统计日期查询父 ASIN 维度的销售表现，可按父 ASIN、品牌和中文品类筛选。

| 参数 | 必填 | 默认值 | 说明 |
|---|---:|---:|---|
| `variation_asin` | 否 | 不限制 | 父 ASIN；留空等同未传 |
| `brand` | 否 | 不限制 | 品牌；留空等同未传 |
| `category_zh` | 否 | 不限制 | 品类（中文）；留空等同未传 |
| `country_code` | 否 | 不限制 | 国家简码；留空等同未传 |
| `country_name` | 否 | 不限制 | 国家名称；留空等同未传 |
| `start_date` | 是 | - | 日期范围开始，按数据库 `statistics_date` 列筛选；缺少时先询问用户 |
| `end_date` | 是 | - | 日期范围结束，按数据库 `statistics_date` 列筛选；缺少时先询问用户 |
| `returnFields` | 否 | 全部字段 | 仅当用户指定需要哪些数据时传入字段名数组 |
| `page` | 否 | 1 | 从 1 开始；下一页、更多或继续时加 1 |
| `page_size` | 否 | 20 | 1-100；单日查询可用 1-5，完整列表可用 50-100 |

默认返回 `v_e_ads_sales_operations_variation_asin` DDL 中全部字段；不再生成视图中不存在的
`gmv` 字段。小数以精确字符串返回，数据库空值保持 `null`。日期使用半开区间实现包含起止日：
`statistics_date >= start` 且 `statistics_date < end + 1 天`，兼容数据库中的时分秒。
`start_date` 和 `end_date` 必须同时提供。用户没有输入完整时间范围时，应先询问用户，不能猜测、
自动补全或使用默认日期。
结果按统计日期和国家稳定排序并分页，使用窗口计数返回 `total`；请求页为空时回退执行总数查询。

## 广告分析工具

以下工具都要求 `variation_asin`、`start_date`、`end_date`。用户未提供父 ASIN 或完整时间范围时，
应先询问用户，不能猜测或使用默认日期。`returnFields` 不传时返回对应视图的全部字段；用户明确
指定所需数据时才传字段名数组。所有日期范围都包含起止日。

| 工具 | 视图 | 日期字段 | 可选筛选 |
|---|---|---|---|
| `get_ad_portfolios` | `v_e_ads_portfolios_analysis` | `report_date` | `portfolio_id` |
| `get_ad_campaigns` | `v_e_ads_merge_campaigns_analysis` | `report_date` | `campaign_id` |
| `get_ad_placements` | `v_e_ads_merge_placement_analysis` | `report_date` | `campaign_id`、`placement_merge` |
| `get_ad_products` | `v_e_ads_merge_product_analysis` | `report_date` | `msku`、`market_id` |
| `get_ad_targetings` | `v_e_ads_merge_targeting_analysis` | `report_date` | `market_id`、`target_id` |
| `get_ad_negative_targetings` | `v_e_ads_merge_negative_targeting_analysis` | `create_time` | `market_id` |
| `get_ad_search_terms` | `v_e_ads_merge_searchterm_analysis` | `report_date` | `market_id`、`query` |

`get_ad_negative_targetings` 的 DDL 不包含 `target_id`，因此该工具没有提供会导致数据库列不存在的
`target_id` 筛选。若后续视图增加此字段，可再同步加入参数与字段白名单。

广告分析工具同样支持 `page`（默认 1）与 `page_size`（默认 20，最大 100）。查询值全部使用参数
绑定，视图名、日期列、筛选列和返回字段均来自服务端固定白名单。

## 测试

```powershell
python -m unittest discover -s tests -v
python -m compileall -q src tests
```

测试不依赖真实 MySQL。连接真实数据库前，请确认上述 10 个视图均存在且账号具备读取权限。
